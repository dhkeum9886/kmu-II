#include "hamout2.h"

extern PREFIX HAM_PMORES morph_anal(
	HAM_PUCHAR sent,	/* input sentence: KSC-5601 code */
	HAM_PMORES2 hamout2,	/* token-based morph. analysis result */
	HAM_PRUNMODE mode);	/* running mode of HAM */
